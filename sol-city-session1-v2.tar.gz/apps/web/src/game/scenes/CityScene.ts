import Phaser from "phaser";
import { TILE_SIZE, MAP_COLS, MAP_ROWS, PLAYER_SPEED } from "../config/constants";
import { getMapData, getSpawnPoint } from "../utils/mapGenerator";
import { AvatarSprite } from "../entities/AvatarSprite";
import { Direction } from "../config/outfitRegistry";

export class CityScene extends Phaser.Scene {
  private avatar!: AvatarSprite;
  private playerBody!: Phaser.Physics.Arcade.Body;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd!: Record<string, Phaser.Input.Keyboard.Key>;
  private collisionLayer!: Phaser.Tilemaps.TilemapLayer;

  constructor() {
    super({ key: "CityScene" });
  }

  create(): void {
    const { ground, collision, width, height } = getMapData();

    // Build the tilemap from raw data
    const map = this.make.tilemap({
      data: this.reshape(ground, width, height),
      tileWidth: TILE_SIZE,
      tileHeight: TILE_SIZE,
    });

    const tileset = map.addTilesetImage("tileset", "tileset", TILE_SIZE, TILE_SIZE, 0, 0);
    if (!tileset) return;

    const groundLayer = map.createLayer(0, tileset, 0, 0);
    if (!groundLayer) return;

    // Collision layer (invisible, used only for physics)
    const collisionMap = this.make.tilemap({
      data: this.reshape(
        collision.map((v) => (v === 0 ? 0 : -1)),
        width,
        height
      ),
      tileWidth: TILE_SIZE,
      tileHeight: TILE_SIZE,
    });

    const collisionTileset = collisionMap.addTilesetImage("tileset", "tileset", TILE_SIZE, TILE_SIZE, 0, 0);
    if (!collisionTileset) return;

    this.collisionLayer = collisionMap.createLayer(0, collisionTileset, 0, 0)!;
    this.collisionLayer.setVisible(false);
    this.collisionLayer.setCollisionByExclusion([-1]);

    // Player avatar with layered outfit
    const spawn = getSpawnPoint();
    const spawnX = spawn.x * TILE_SIZE + TILE_SIZE / 2;
    const spawnY = spawn.y * TILE_SIZE + TILE_SIZE / 2;

    this.avatar = new AvatarSprite(this, spawnX, spawnY, "default");

    // Physics body on the container
    const container = this.avatar.getContainer();
    this.physics.world.enable(container);
    this.playerBody = container.body as Phaser.Physics.Arcade.Body;
    this.playerBody.setSize(TILE_SIZE * 0.6, TILE_SIZE * 0.4);
    this.playerBody.setOffset(-TILE_SIZE * 0.3, -TILE_SIZE * 0.1);
    this.playerBody.setCollideWorldBounds(true);

    this.physics.add.collider(container, this.collisionLayer);
    this.physics.world.setBounds(0, 0, MAP_COLS * TILE_SIZE, MAP_ROWS * TILE_SIZE);

    // Camera
    this.cameras.main.setBounds(0, 0, MAP_COLS * TILE_SIZE, MAP_ROWS * TILE_SIZE);
    this.cameras.main.startFollow(container, true, 0.08, 0.08);
    this.cameras.main.setZoom(2);
    this.cameras.main.setBackgroundColor(0x081828);

    // Input
    this.cursors = this.input.keyboard!.createCursorKeys();
    this.wasd = {
      up: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.W),
      down: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.S),
      left: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.A),
      right: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.D),
    };
  }

  update(): void {
    this.playerBody.setVelocity(0);

    const up = this.cursors.up.isDown || this.wasd.up.isDown;
    const down = this.cursors.down.isDown || this.wasd.down.isDown;
    const left = this.cursors.left.isDown || this.wasd.left.isDown;
    const right = this.cursors.right.isDown || this.wasd.right.isDown;

    let direction: Direction | null = null;

    if (left) { this.playerBody.setVelocityX(-PLAYER_SPEED); direction = "left"; }
    else if (right) { this.playerBody.setVelocityX(PLAYER_SPEED); direction = "right"; }

    if (up) { this.playerBody.setVelocityY(-PLAYER_SPEED); direction = direction ?? "up"; }
    else if (down) { this.playerBody.setVelocityY(PLAYER_SPEED); direction = direction ?? "down"; }

    // Normalize diagonal movement
    if ((left || right) && (up || down)) {
      this.playerBody.velocity.normalize().scale(PLAYER_SPEED);
    }

    if (direction) {
      this.avatar.walk(direction);
    } else {
      this.avatar.idle();
    }

    // Depth sort: avatar renders behind/in front of things based on Y
    this.avatar.updateDepth();
  }

  /** Reshapes a flat array into a 2D grid for Phaser's tilemap data format. */
  private reshape(flat: number[], cols: number, rows: number): number[][] {
    const grid: number[][] = [];
    for (let r = 0; r < rows; r++) {
      grid.push(flat.slice(r * cols, (r + 1) * cols));
    }
    return grid;
  }
}
