export const TILE_SIZE = 32;
export const MAP_COLS = 30;
export const MAP_ROWS = 20;
export const MAP_WIDTH = MAP_COLS * TILE_SIZE;
export const MAP_HEIGHT = MAP_ROWS * TILE_SIZE;

export const PLAYER_SPEED = 160;

export const COLORS = {
  PURPLE: 0x9945ff,
  GREEN: 0x14f195,
  CYAN: 0x00d1ff,
  DARK: 0x0e0e2c,
  MID: 0x1a1a3e,
  GOLD: 0xffd700,
  ORANGE: 0xff6b35,
  PINK: 0xf72585,
  GRASS_A: 0x2b6b1e,
  GRASS_B: 0x358228,
  PATH: 0xa89060,
  PLAZA: 0x9088a0,
  SAND: 0xc8b078,
  WATER: 0x0b3b5c,
  BUILDING_JUPITER: 0xc8960f,
  BUILDING_POST: 0x1878a8,
  BUILDING_GUILD: 0xcc4422,
  BUILDING_SUPERTEAM: 0x7040bb,
} as const;

// Tile indices used in the programmatic tilemap.
// These map to rows in the generated tileset texture.
export enum Tile {
  GRASS_A = 0,
  GRASS_B = 1,
  PATH = 2,
  PLAZA = 3,
  SAND = 4,
  WATER_DEEP = 5,
  WATER = 6,
  DOCK = 7,
  BUILDING = 8,
  PARK = 9,
  FLOWERS = 10,
}
