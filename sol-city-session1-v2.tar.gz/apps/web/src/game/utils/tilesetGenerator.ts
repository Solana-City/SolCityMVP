import { TILE_SIZE, COLORS, Tile } from "../config/constants";

// Maps each Tile enum to a fill color.
const TILE_COLORS: Record<number, number> = {
  [Tile.GRASS_A]: COLORS.GRASS_A,
  [Tile.GRASS_B]: COLORS.GRASS_B,
  [Tile.PATH]: COLORS.PATH,
  [Tile.PLAZA]: COLORS.PLAZA,
  [Tile.SAND]: COLORS.SAND,
  [Tile.WATER_DEEP]: 0x081828,
  [Tile.WATER]: COLORS.WATER,
  [Tile.DOCK]: 0x7a6545,
  [Tile.BUILDING]: COLORS.MID,
  [Tile.PARK]: 0x1d7a12,
  [Tile.FLOWERS]: COLORS.GRASS_A,
};

const TILE_COUNT = Object.keys(TILE_COLORS).length;

/**
 * Generates a tileset texture at runtime.
 * Each tile is rendered as a colored square in a vertical strip.
 * This avoids needing an external PNG for the initial prototype.
 */
export function generateTileset(scene: Phaser.Scene): void {
  const width = TILE_SIZE;
  const height = TILE_SIZE * TILE_COUNT;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d")!;

  for (let i = 0; i < TILE_COUNT; i++) {
    const color = TILE_COLORS[i] ?? 0x333333;
    ctx.fillStyle = `#${color.toString(16).padStart(6, "0")}`;
    ctx.fillRect(0, i * TILE_SIZE, TILE_SIZE, TILE_SIZE);

    // Subtle grid line for visual clarity
    ctx.fillStyle = "rgba(0,0,0,0.06)";
    ctx.fillRect(0, i * TILE_SIZE, TILE_SIZE, 1);
    ctx.fillRect(0, i * TILE_SIZE, 1, TILE_SIZE);
  }

  scene.textures.addCanvas("tileset", canvas);
}
