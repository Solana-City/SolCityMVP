"use client";

import dynamic from "next/dynamic";

const PhaserGame = dynamic(() => import("@/game/PhaserGame"), { ssr: false });

export default function Home() {
  return (
    <main className="w-screen h-screen relative">
      <PhaserGame />
    </main>
  );
}
