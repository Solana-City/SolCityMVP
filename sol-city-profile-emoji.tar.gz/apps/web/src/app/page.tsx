"use client";

import { useState, useEffect, useCallback } from "react";
import dynamic from "next/dynamic";
import SolanaProvider from "@/ui/SolanaProvider";
import WalletBar from "@/ui/WalletBar";
import ChatPanel from "@/ui/ChatPanel";
import NPCDialog from "@/ui/NPCDialog";
import ActionPanel from "@/ui/ActionPanel";
import ProfilePanel from "@/ui/ProfilePanel";
import type { NPCDefinition, NPCAction } from "@/game/config/npcRegistry";

const PhaserGame = dynamic(() => import("@/game/PhaserGame"), { ssr: false });

export default function Home() {
  const [game, setGame] = useState<Phaser.Game | null>(null);
  const [activeNPC, setActiveNPC] = useState<NPCDefinition | null>(null);
  const [activeAction, setActiveAction] = useState<NPCAction | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);

  useEffect(() => {
    if (!game) return;
    const handler = (npc: NPCDefinition) => {
      setActiveNPC(npc);
    };
    game.events.on("npc:interact", handler);
    return () => {
      game.events.off("npc:interact", handler);
    };
  }, [game]);

  const handleDialogClose = useCallback(() => {
    setActiveNPC(null);
    game?.events.emit("npc:close");
  }, [game]);

  const handleAction = useCallback((action: NPCAction) => {
    setActiveNPC(null);
    setActiveAction(action);
  }, []);

  const handleActionClose = useCallback(() => {
    setActiveAction(null);
    game?.events.emit("npc:close");
  }, [game]);

  // P key opens profile
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "p" || e.key === "P") {
        const active = document.activeElement;
        if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA")) return;
        setProfileOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <SolanaProvider>
      <main className="w-screen h-screen relative">
        <PhaserGame onGameReady={setGame} />

        {/* HUD top-right: profile button + wallet */}
        <div className="fixed top-4 right-4 z-20 flex items-center gap-2">
          <button
            onClick={() => setProfileOpen(true)}
            className="px-3 py-2 rounded text-xs cursor-pointer"
            style={{
              background: "rgba(10,10,30,0.88)",
              color: "#14F195",
              border: "1px solid rgba(20,241,149,0.2)",
              fontFamily: '"Press Start 2P", monospace',
              fontSize: "8px",
            }}
          >
            [P] PROFILE
          </button>
          <WalletBar />
        </div>

        <ChatPanel gameRef={game} />
        <NPCDialog npc={activeNPC} onClose={handleDialogClose} onAction={handleAction} />
        <ActionPanel action={activeAction} onClose={handleActionClose} />
        <ProfilePanel gameRef={game} isOpen={profileOpen} onClose={() => setProfileOpen(false)} />
      </main>
    </SolanaProvider>
  );
}
