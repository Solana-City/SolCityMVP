"use client";

import { useState, useEffect, useCallback } from "react";
import type { PlayerProfile } from "@/game/config/profileManager";
import type { ProfileManager } from "@/game/config/profileManager";

interface ProfilePanelProps {
  gameRef: Phaser.Game | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ProfilePanel({ gameRef, isOpen, onClose }: ProfilePanelProps) {
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [manager, setManager] = useState<ProfileManager | null>(null);
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState("");

  useEffect(() => {
    if (!gameRef) return;
    const check = setInterval(() => {
      const scene = gameRef.scene.getScene("CityScene");
      if (scene) {
        const pm = scene.registry.get("profileManager") as ProfileManager | undefined;
        if (pm) {
          setManager(pm);
          setProfile(pm.get());
          pm.onChange((p) => setProfile({ ...p }));
          clearInterval(check);
        }
      }
    }, 200);
    return () => clearInterval(check);
  }, [gameRef]);

  const saveName = useCallback(() => {
    if (manager && nameInput.trim()) {
      manager.setDisplayName(nameInput.trim());
    }
    setEditingName(false);
  }, [manager, nameInput]);

  const selectOutfit = useCallback(
    (outfitId: string) => {
      if (!manager || !gameRef) return;
      manager.setOutfit(outfitId);
      gameRef.events.emit("profile:outfit", outfitId);
    },
    [manager, gameRef]
  );

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, onClose]);

  if (!isOpen || !profile) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0"
        style={{ background: "rgba(6,10,20,0.6)" }}
        onClick={onClose}
      />
      <div
        className="relative rounded-2xl p-6 w-full max-w-sm"
        style={{
          background: "rgba(10,10,30,0.97)",
          border: "1px solid rgba(153,69,255,0.25)",
          fontFamily: '"Fira Code", monospace',
        }}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-lg cursor-pointer"
          style={{ background: "none", border: "none", color: "#555566" }}
        >
          ×
        </button>

        <h3
          style={{
            fontFamily: '"Press Start 2P", monospace',
            fontSize: "11px",
            color: "#14F195",
            marginBottom: "16px",
          }}
        >
          PROFILE
        </h3>

        {/* Display name */}
        <div className="mb-4">
          <div className="text-xs mb-1" style={{ color: "#555566" }}>
            Display name
          </div>
          {editingName ? (
            <div className="flex gap-2">
              <input
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && saveName()}
                maxLength={20}
                autoFocus
                className="flex-1 px-2 py-1 text-sm rounded outline-none"
                style={{
                  background: "#12122a",
                  color: "#fff",
                  border: "1px solid rgba(153,69,255,0.2)",
                  fontFamily: "monospace",
                }}
              />
              <button
                onClick={saveName}
                className="px-3 py-1 rounded text-xs cursor-pointer"
                style={{ background: "#14F195", color: "#000", border: "none" }}
              >
                Save
              </button>
            </div>
          ) : (
            <div
              className="flex justify-between items-center cursor-pointer px-2 py-1.5 rounded"
              style={{ background: "#12122a" }}
              onClick={() => {
                setNameInput(profile.displayName);
                setEditingName(true);
              }}
            >
              <span style={{ color: "#fff" }}>{profile.displayName}</span>
              <span style={{ color: "#555566", fontSize: "10px" }}>edit</span>
            </div>
          )}
        </div>

        {/* Wallet */}
        <div className="mb-4">
          <div className="text-xs mb-1" style={{ color: "#555566" }}>
            Wallet
          </div>
          <div className="px-2 py-1.5 rounded" style={{ background: "#12122a" }}>
            <span style={{ color: "#00D1FF", fontSize: "12px" }}>
              {profile.wallet ?? "Not connected"}
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <StatCard label="Score" value={profile.score} color="#FFD700" />
          <StatCard label="Swaps" value={profile.swapCount} color="#14F195" />
          <StatCard label="Transfers" value={profile.transferCount} color="#00D1FF" />
          <StatCard label="Bounties" value={profile.bountyCount} color="#9945FF" />
        </div>

        {/* Outfits */}
        <div className="mb-2">
          <div className="text-xs mb-2" style={{ color: "#555566" }}>
            Outfits ({profile.unlockedOutfits.length})
          </div>
          <div className="flex flex-wrap gap-1.5">
            {profile.unlockedOutfits.map((id) => (
              <button
                key={id}
                onClick={() => selectOutfit(id)}
                className="px-2 py-1 rounded text-xs cursor-pointer"
                style={{
                  background:
                    profile.outfitId === id
                      ? "rgba(20,241,149,0.15)"
                      : "#12122a",
                  color:
                    profile.outfitId === id ? "#14F195" : "#888899",
                  border:
                    profile.outfitId === id
                      ? "1px solid rgba(20,241,149,0.3)"
                      : "1px solid rgba(255,255,255,0.05)",
                  fontFamily: "monospace",
                }}
              >
                {id}
              </button>
            ))}
          </div>
        </div>

        {/* Emoji hint */}
        <div
          className="mt-4 text-xs text-center"
          style={{ color: "#333344" }}
        >
          Press 1-6 in-game for quick emotes
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div
      className="rounded-lg p-2.5 text-center"
      style={{ background: "#12122a" }}
    >
      <div className="text-xs" style={{ color: "#555566" }}>
        {label}
      </div>
      <div
        className="text-lg font-bold mt-0.5"
        style={{ color, fontFamily: '"Press Start 2P", monospace', fontSize: "14px" }}
      >
        {value}
      </div>
    </div>
  );
}
